import os
import json
import random

if __name__ == '__main__':
    existing_clteach_dir = '../../data/clteach/clteach data'
    filelist = os.listdir(existing_clteach_dir)
    filelist = [int(file.split('_')[-1].replace('.xlsx','')) for file in filelist]


    all_questions = json.load(open('questions.json','r',encoding='utf-8'))

    new_questions = []
    for q_id, q in enumerate(all_questions):
        if q_id not in filelist:
            new_questions.append(q)

    new_questions = random.sample(new_questions,30)
    with open('new_questions.json','w',encoding='utf-8') as f:
        json.dump(new_questions,f,ensure_ascii=False,indent=4)
