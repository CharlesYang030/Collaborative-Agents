import os

import pandas as pd

# dir = 'debatepedia/argumentUnits'
#
# outfile = open('debatepedia_questions.txt','w',encoding='utf-8')
# filelist = os.listdir(dir)
# for i,file in enumerate(filelist):
#     file_path = os.path.join(dir,file)
#     content = open(file_path,'r',encoding='utf-8').readlines()
#     question = content[0].strip()
#     outfile.write(str(i)+'\t'+question+'\n')
# outfile.close()
# exit()


dir = 'debatepedia/argumentUnits'

data = []
filelist = os.listdir(dir)
for i,file in enumerate(filelist):
    file_path = os.path.join(dir,file)
    content = open(file_path,'r',encoding='utf-8').readlines()
    question = content[0].strip()


    relation_file_path = os.path.join('debatepedia/relations',file)
    relation_content = open(relation_file_path,'r',encoding='utf-8').readlines()
    assert len(content)-1 == len(relation_content)
    views = pd.DataFrame(columns=['view','flag'])
    for row,(view,flag) in enumerate(zip(content[1:],relation_content)):
        view = view.strip()
        flag = flag.strip().split()[-1]
        views.at[row,'view'] = view
        views.at[row,'flag'] = flag
    support_df = views[views['flag']=='support'].reset_index(drop=True)
    support_list = list(support_df['view'].unique())
    attack_df = views[views['flag']=='attack'].reset_index(drop=True)
    attack_list = list(attack_df['view'].unique())
    data.append({
        'question':question,
        'support_list':support_list,
        'attack_list':attack_list
    })

import json
with open('questions.json','w',encoding='utf-8') as f:
    json.dump(data,f,ensure_ascii=False,indent=3)


